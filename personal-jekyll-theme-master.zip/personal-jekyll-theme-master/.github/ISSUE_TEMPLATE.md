## Questions

Please ask your questions at the [gitter channel](https://gitter.im/PanosSakkos/personal-jekyll-theme).
That way the issues here are kept clean and you will get an answer to your question quicker :smile:

## Expected Behavior


## Actual Behavior


## Steps to Reproduce the Issue

  1.
  2.
  3.

## Specifications

(The version of the project, browser etc.)
